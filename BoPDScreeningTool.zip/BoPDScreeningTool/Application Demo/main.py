import os

path = os.getcwd()
os.chdir(path)
import subprocess
import sys


subprocess.call([sys.executable, 'temp.py'])
