skorch
======

.. toctree::
   :maxdepth: 2

   callbacks
   classifier
   dataset
   exceptions
   helper
   history
   net
   regressor
   scoring
   toy
   utils
