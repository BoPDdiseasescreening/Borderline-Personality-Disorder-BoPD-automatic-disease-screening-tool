skorch.dataset
==============

.. automodule:: skorch.dataset
	:members:
