## To build locally

```bash
make html
firefox _build/html/index.html
```
