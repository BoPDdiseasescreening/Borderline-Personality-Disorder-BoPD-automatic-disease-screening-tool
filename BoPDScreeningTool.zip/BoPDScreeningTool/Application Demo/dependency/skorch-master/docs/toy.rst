skorch.toy
==========

.. automodule:: skorch.toy
	:members:
