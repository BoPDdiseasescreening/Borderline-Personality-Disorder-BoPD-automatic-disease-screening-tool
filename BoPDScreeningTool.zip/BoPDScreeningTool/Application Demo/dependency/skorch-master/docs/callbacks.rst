skorch.callbacks
================

.. automodule:: skorch.callbacks
	:members:
