skorch.history
==============

.. automodule:: skorch.history
	:members:
