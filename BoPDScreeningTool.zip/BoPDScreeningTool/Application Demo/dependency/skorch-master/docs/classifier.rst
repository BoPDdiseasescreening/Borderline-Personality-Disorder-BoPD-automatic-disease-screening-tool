skorch.classifier
=================

.. automodule:: skorch.classifier
    :members:
