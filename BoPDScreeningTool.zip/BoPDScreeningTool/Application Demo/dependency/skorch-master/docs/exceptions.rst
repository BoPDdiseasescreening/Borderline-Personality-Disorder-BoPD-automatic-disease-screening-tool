skorch.exceptions
=================

.. automodule:: skorch.exceptions
	:members:
