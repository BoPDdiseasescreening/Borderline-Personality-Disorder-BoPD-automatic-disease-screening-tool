
#import file


import tkinter as tk
import scipy
import os

from tkinter import filedialog
from tkinter import ttk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename
from tkinter.messagebox import showerror


import numpy as np
import pandas as pd
import time
from collections import defaultdict
import sys
import seaborn as sns
import pickle as pkl
import math
import itertools


import pickle
import time
from time import gmtime, strftime
import torch
from torch import nn
import torch.nn.functional as F
import skorch
from skorch import NeuralNetClassifier

from datetime import date
import psutil
import gc 
from datetime import datetime

gc.collect()

b_selected_feature = False # default false
b_dump = True   # default true
b_sort_force = True #default false
b_ccsr_encoding = True


#Read in main dataset 

os.chdir('C:\BoPDScreeningTool\Application Demo') #please use local C:/ path
   
df_cohort = pd.read_csv('C:\BoPDScreeningTool\Application Demo\gold_test.csv') #path for patient input dataset

df_cohort.rename(columns={x:x.split('.')[-1] for x in df_cohort.columns}, inplace=True)
df_cohort = df_cohort.reset_index()

#read in ICD10 code dictionary
code= pd.read_excel (r'Appendix_1.xlsx')

#select input columns
correct_name_list=['patient_sk', 'gender', 'encounter_id', 'diagnosis_code', 'diagnosis_type','age_in_years', 
'admitted_dt_tm', 'discharged_dt_tm', 'patient_type_desc']

            
###################Data quality check 
           
# Step 1: check column name and counts
test_name=df_cohort.columns
error = 0

message = "   "
message+="Step 1: check column name and counts\n"
dic_correct_name={}
for i in correct_name_list:
    dic_correct_name[i]=0
extra_name=[]
  
for i in test_name:
    if i in dic_correct_name:
        dic_correct_name[i]+=1
    else:
        extra_name.append(i)

for i in dic_correct_name:
    if dic_correct_name[i] == 0:
        message+="Missing column: "
        message+=i
        message+="\n"
        error+=1
  
  
  
for name in extra_name:
    message+="Extra column: "
    message+=name
    message+="\n"
 
  
  
# step 2: check data type for each column
dict_stand_column_types={
 'gender': np.dtype('O'),
 'diagnosis_code': np.dtype('O'),
 'diagnosis_type': np.dtype('O'),
 #'age_in_years': np.dtype('int64'),
 'admitted_dt_tm': np.dtype('O'),
 'discharged_dt_tm': np.dtype('O'),
 'patient_type_desc': np.dtype('O'), 
}
            
dict_df_type=df_cohort.dtypes.to_dict()


message+="\n"
message+="Step 2: check data type for each column\n"
for column in dict_df_type:
    if column not in dict_stand_column_types:
        print("Not checked:", column)
    elif dict_df_type[column] != dict_stand_column_types[column]:  
        message+="Incorrect data type: "
        message+=column
        message+="\n"
        error+=1
    else:
        message+=column
        message+=": No issue\n"
        
# Step 3: check the age range (18 to 65)
# 1.Age range
# 2. Consistency of birth year
message+="\n"
message+="Step 3: check age \n"
message+="   -Step 3.1: check the age range (18 to 65)\n"
age_check=df_cohort.query('age_in_years<18' or 'age_in_year>65')
if len(age_check)>10:
         message+="Only 10 records are printed:\n" 
         age_check=age_check.iloc[0:10]
age_list=age_check["patient_sk"].values.tolist()


if age_check.empty:
    message+="Age is in range"
    message+="\n"
else:
        for i in age_list:
            message+="Patient_sk "
            message+=str(i)
            message+=": Age is out of range"
            error+=1
            message+="\n"
            
del [age_check,age_list] 

message+="\n"
message+="   -Step 3.2: check birth year\n"

df_cohort['admitted_dt_tm'] = pd.to_datetime(df_cohort['admitted_dt_tm']) 
df_cohort['discharged_dt_tm'] = pd.to_datetime(df_cohort['discharged_dt_tm'])
df_cohort['birth_year']=df_cohort['discharged_dt_tm'].apply(lambda x:x.year) - df_cohort['age_in_years']

group_df=df_cohort.groupby(by='patient_sk', as_index=False)
min_year=group_df.agg({'birth_year': pd.Series.min})


max_year=group_df.agg({'birth_year': pd.Series.max})
max_year['birth_year_min'] = min_year['birth_year']
max_year['diff']=max_year['birth_year']-max_year['birth_year_min']

birth_check=max_year[max_year['diff']>2]
    
if len(birth_check)>10:
    message+="Only 10 records are printed:\n"
    birth_check=birth_check.iloc[0:10]
birth_list=birth_check["patient_sk"].values.tolist()
if birth_check.empty:
        message+="No issue"
        message+="\n"
else:
        for i in birth_list:
            message+="Patient_sk "
            message+=str(i)
            message+=" has inconsistent birth_year (difference >=3 years)"
            message+="\n"
            error+=1
    
del [max_year, birth_check, birth_list]

# Step 4: Check gender values - only Female, Male, Other is allowed
gender_check=df_cohort.query('gender not in ["Female","Male"]')
if len(gender_check)>10:
    message+="Only 10 records are printed:\n"
    gender_check=gender_check.iloc[0:10]
gen_list=gender_check["patient_sk"].values.tolist()

message+="\n"
message+="Step 4: Check gender \n"
message+="  -Step 4.1: Check values - possible value: 'Female', 'Male'\n"
if gender_check.empty:
        message+="Gender is in range"
        message+="\n"
       # print('Gender is in range')
else:
        for i in gen_list:
            message+="Patient_sk "
            message+=str(i)
            message+=": Gender has invalid value"
            message+="\n"
            error+=1
            
del [gender_check, gen_list]
    
message+="\n"
message+="  -Step 4.2: Check consistency\n"
count_gender = group_df.agg({'gender': pd.Series.nunique})
gender_check2=count_gender.query('gender>1')
if len(gender_check2)>10:
    message+="Only 10 records are printed:\n"
    gender_check2=gender_check2.iloc[0:10]
gen_list2=gender_check2["patient_sk"].values.tolist()
if gender_check2.empty:
        message+="Gender is consistent for all patients"
        message+="\n"
else:
        for i in gen_list2:
            message+="Patient_sk "
            message+=str(i)
            message+=": Gender is not consistent over time"
            message+="\n"
            error+=1

del [count_gender, gender_check2, gen_list2]

# Step 5: Check dates: 
# 5.1 discharged date should be after 2017-01-01
# 5.2 discharged date cannot be prior to admitted date 
message+="\n"
message+="Step 5: Check dates\n"
message+="  -Step 5.1: Discharged date should >=2017-01-01 \n"

date_check1=df_cohort[df_cohort['discharged_dt_tm'] < pd.Timestamp(2017,1,1)]

date_check1_nodup=date_check1.drop_duplicates(subset = ["patient_sk", "discharged_dt_tm"])
if len(date_check1_nodup)>10:     
    date_check1_nodup=date_check1_nodup.iloc[0:10]
    message+="Only 10 records are printed:\n"
if date_check1.empty:
        message+="No issue"
        message+="\n"
else:
        message+=date_check1_nodup[['patient_sk','discharged_dt_tm']].to_string()
        message+="\n"
        error+=1
        
del [date_check1, date_check1_nodup]

message+="\n"
message+="  -Step 5.2: Discharged date cannot be prior to admitted date\n"
date_check2=df_cohort[df_cohort.admitted_dt_tm>df_cohort.discharged_dt_tm]  
date_check2_nodup=date_check2.drop_duplicates(subset = ["patient_sk",'admitted_dt_tm',"discharged_dt_tm"])
if len(date_check2_nodup)>10:   
    date_check2_nodup=date_check2_nodup.iloc[0:10]
    message+="Only 10 records are printed:\n"
if date_check2.empty:
        message+="No issue"
        message+="\n"
    
else:
        message+=date_check2_nodup[['patient_sk','admitted_dt_tm','discharged_dt_tm']].to_string()
        message+="\n"
        error+=1
    
     
del [date_check2, date_check2_nodup]

# Step 6: Multiple patient_sk corresponding to one encounter_id
# Step 6: Multiple patient_sk corresponding to one encounter_id
message+="\n"
message+=" Step 6: Check encounter_id and patient_sk\n"
group_encounter=df_cohort.groupby(by='encounter_id', as_index=False)
count_enc = group_encounter.agg({'patient_sk': pd.Series.nunique})
enc_check=count_enc.query('patient_sk>1')
if len(enc_check)>10:
     enc_check=enc_check.iloc[0:10]

enc_list=enc_check["encounter_id"].values.tolist()
if enc_check.empty:
    message+="No issue"
    message+="\n"
else:
    for i in enc_list:
        message+="Encounter_id "
        message+=str(i)
        message+=" is corresponding to multiple patient_sk's"
        message+="\n"
        error+=1

del [count_enc, group_encounter, enc_check]
    
# Step 7: Check patient history (5+ encounters on different discharged dates or 2+ emergency visits)


count_discharge = group_df.agg({'discharged_dt_tm': pd.Series.nunique})
check_his1=count_discharge[count_discharge.discharged_dt_tm>=5]
emer=df_cohort[df_cohort.patient_type_desc.str.upper()=='EMERGENCY']
count_emer = emer.groupby(by='patient_sk', as_index=False).agg({'discharged_dt_tm': pd.Series.nunique})
check_his2=count_emer[count_emer.discharged_dt_tm>=2]
a=set(check_his1['patient_sk'])
b=set(check_his2['patient_sk'])
c=set(df_cohort['patient_sk'])
check_his=a.union(b)

key_diff = c-check_his 


message+="\n"
message+="Step 7: Check patient history \n"
message+="     - 5+ encounters on different discharged dates or 2+ emergency visits\n"
count=0
if len(key_diff)==0:
        message+="No issue"
        message+="\n"
elif len(key_diff)>10:
        message+="Only 10 records are printed:\n"
        for i in iter(key_diff):
            message+= "patient_sk "
            message+= str(i)
            message+=" doesn't have sufficient history"
            message+="\n"
            error+=1
            count=count+1
            if count==10:
                break

else:
        for i in iter(key_diff):
            message+= "patient_sk "
            message+= str(i)
            message+=" doesn't have sufficient history"
            message+="\n"
            error+=1

    
# Step 8: Check inclusion codelist
message+="\n"
message+="Step 8: Check inclusion codelist \n"
code_list=code["ICD10_CODE"].values.tolist()

df_cohort["flag"] = df_cohort["diagnosis_code"].str.replace(".", "").isin(code_list)
# derive age_of_first_diagnosis
age_derive=df_cohort.query('flag>0')
group_age=age_derive.groupby(by='patient_sk', as_index=False)
age=group_age.agg({'age_in_years': pd.Series.min})
age.rename(columns={"age_in_years":"age_first_diag"},inplace = True)


df_cohort['diagnosis_code_1'] = df_cohort["diagnosis_code"].str.replace(".", "")

count_code=group_df.agg({'flag': pd.Series.sum})
code_check=count_code.query('flag==0')
if len(code_check)>10:
    message+="Only 10 records are printed:\n"
    code_check=code_check.iloc[0:10]
ex_list=code_check["patient_sk"].values.tolist()
if code_check.empty:
        message+="No issue"
        message+="\n"
else:
        for i in ex_list:
            message+="Patient_sk "
            message+=str(i)
            message+=" doesn't have any required codes in the inclusion list (Appendix_1)"
            message+="\n"
            error+=1                
            
del [code_list, count_code, code_check,ex_list]

# last step: print total number of errors
message+="\n"
message+="Summary: there are "  
message+=str(error)
message+=" errors in total in the input dataset"

print(message)
#please update input dataset following message instructions 
###########Data quality check is done

##########Lulu's comment ends here###################################33


df3=df_cohort.drop(columns=['birth_year','flag'])
final_df=pd.merge(df3,min_year,how='left',on='patient_sk')
final_df=pd.merge(final_df,age,how='left',on='patient_sk')
                    
#######Data Preprocessing


#finalize input columns for next step: format adjustments and sorting
final_df.rename(columns={x:x.split('.')[-1] for x in final_df.columns}, inplace=True)

final_df=final_df[['patient_sk', 'gender', 'encounter_id',
'diagnosis_code','diagnosis_code_1', 'diagnosis_type','age_first_diag','age_in_years', 'birth_year',
'admitted_dt_tm', 'discharged_dt_tm',
'patient_type_desc']]
 
final_df.sort_values(by=['patient_sk', 'discharged_dt_tm'], inplace=True)

#Duplicates removal
final_df = final_df.drop_duplicates(subset = ["patient_sk", 
                                             "encounter_id", 
                                             "diagnosis_code", 
                                             "discharged_dt_tm"])

 

#Load feature code
      

#age filter: if patient is [18,65] as of now
final_df['age_now'] = datetime.now().year - final_df['birth_year']
final_df = final_df[(final_df['age_now'] >= 18) & (final_df['age_now'] <= 65)]

#load CCSR code 
df_ccsr = pd.read_excel('DXCCSR_v2020-2.xlsx',index_col=0)
    
df_ccsr.index = df_ccsr.index.map(lambda x:x.strip(r"'\""))

df_ccsr['Default-CCSR-CATEGORY'] = df_ccsr['Default-CCSR-CATEGORY'].map(lambda x:x.strip(r"'\""))
df_ccsr['CCSR-CATEGORY-1'] = df_ccsr['CCSR-CATEGORY-1'].map(lambda x:x.strip(r"'\""))
df_ccsr['CCSR-CATEGORY-2'] = df_ccsr['CCSR-CATEGORY-2'].map(lambda x:x.strip(r"'\""))


    
df_ccsr_1 = df_ccsr[['Default-CCSR-CATEGORY','Default-CCSR-CATEGORY-DESCRIPTION']]
df_cohort_1 = final_df.merge(df_ccsr_1, left_on='diagnosis_code_1', right_index=True, how='left' )
del df_cohort_1['diagnosis_code_1']

df_cohort_2 = df_cohort_1[df_cohort_1['Default-CCSR-CATEGORY'].isin(['MBD002','MBD003','MBD004','MBD005','MBD007','MBD008','MBD009','MBD012','MBD027',
   'MBD017','MBD018','MBD019','MBD020','MBD021','MBD022','MBD023','MBD025'])]

df_cohort_2['group_mbd'] = df_cohort_2['Default-CCSR-CATEGORY']
df_cohort_2 = df_cohort_2.reset_index()


df_cohort_2.loc[df_cohort_2['Default-CCSR-CATEGORY'].isin(['MBD012','MBD027']), 'group_mbd'] = 'suicidal'
df_cohort_2.loc[df_cohort_2['Default-CCSR-CATEGORY'].isin(['MBD003']), 'group_mbd'] = 'bipolar'
df_cohort_2.loc[df_cohort_2['Default-CCSR-CATEGORY'].isin( ['MBD017','MBD018','MBD019','MBD020','MBD021','MBD022','MBD023','MBD025']), 'group_mbd'] = 'MBD_sub'



df_cohort_sb = df_cohort_2[(df_cohort_2['group_mbd'] == 'suicidal') | (df_cohort_2['group_mbd'] =='bipolar')]
sb_list=df_cohort_2[df_cohort_2.patient_sk.isin(df_cohort_sb.patient_sk)].patient_sk.unique() 
sb_list = sb_list.tolist()
df_cohort_other = df_cohort_2[~df_cohort_2.patient_sk.isin(sb_list)]
ct_other = df_cohort_other.groupby('patient_sk')['group_mbd'].nunique()
ct_other1 = pd.DataFrame(data=ct_other)
ct_other1['suicide_bipolar_flag']='N'


df_cohort_sb1 = df_cohort_2[df_cohort_2.patient_sk.isin(sb_list)]
ct_sb = df_cohort_sb1.groupby('patient_sk')['group_mbd'].nunique()
ct_sb1 = pd.DataFrame(data=ct_sb)
ct_lt = ct_sb1[ct_sb1['group_mbd'] < 3]
ct_lt['suicide_bipolar_flag']='Y2'
ct_gt = ct_sb1[ct_sb1['group_mbd'] >= 3]
ct_gt['suicide_bipolar_flag']='Y1'

df_cohort_3 = pd.concat([ct_gt,ct_lt,ct_other1])
        
df_cohort_ = df_cohort_1.merge(df_cohort_3, left_on='patient_sk', right_index=True, how='left' )

del df_cohort_['group_mbd']


##################################Zheng's comment starts here#################################
#Load filtered code vector file as topcode

df_topcode  = pd.read_excel('ICD10 code rating.xlsx',index_col=0)
df_topcode['ccsr_code']=''
df_topcode['ccsr_description']=''
for index, row in df_topcode.iterrows():
    diagnosis_code = row['diagnosis_code']
    diagnosis_description = row['diagnosis_description']
    icd_code = diagnosis_code.replace('.', '')
    try:
        ccsr_code =  df_ccsr.loc[icd_code, 'Default-CCSR-CATEGORY']
        ccsr_description = df_ccsr.loc[icd_code, 'Default-CCSR-CATEGORY-DESCRIPTION']            
        if ccsr_code == 'XXX000':
            ccsr_code =  df_ccsr.loc[icd_code, 'CCSR-CATEGORY-1']
            ccsr_description = df_ccsr.loc[icd_code, 'CCSR-CATEGORY-1-DESCRIPTION']
    except KeyError:
        #Here is no ccsr code for F43.1, MBD007 will be assigned to it.     
        if icd_code == 'F431':
            ccsr_code = 'MBD007'
            ccsr_description = 'Trauma- and stressor-related disorders'
 
    df_topcode.loc[index, 'ccsr_code']=ccsr_code
    df_topcode.loc[index, 'ccsr_description']=ccsr_description


# Step 2, Define feature space
# - ICD-code with top prevalence
# - Demographic: gender, age, with age group in at least these three categories 18-39, 40-59, 60+ 
# - Encounter type (emergency, inpatient, and group everything else as outpatient) 
# - [not used so far] Corresponding CCSR groups of above selected ICD-10 codes
patient_vec = df_cohort_['patient_sk'].unique() #shape: (228,)  numpy.ndarray
N = patient_vec.shape[0]  # 


        
## Feature space 
### Feature part I, ICD codes
if b_selected_feature:
### Feature part I,  ICD code feature, only select dr annotated features

    df_topcode_filtered = df_topcode.loc[df_topcode[r'Rating'] != r'C: unrelated with BoPD']  
else:
       
    df_topcode_filtered = df_topcode  #['diagnosis_code'].values 

if b_ccsr_encoding:
    icd_ccsr = {}
    rating_appendix = {'A': 'negative', 'B': 'positive', 'C' : 'unrelated', 'D': 'unsure'}
    for index, row in df_topcode_filtered.iterrows():
        diagnosis_description = row['diagnosis_description']
        rating = row['Rating']
        ccsr_code = row['ccsr_code']
        ccsr_description = row['ccsr_description']
        diagnosis_code = row['diagnosis_code'] 
        icd_ccsr[diagnosis_code] = ccsr_code + '_' + rating_appendix[rating[0]]

    code_vec = np.sort( np.array(list(set(icd_ccsr.values()))) )
else: # default icd-encoding
    code_vec = df_topcode_filtered.index  
        
        
    ### Feature part II
    ### demographics, behaviors and time
    #    e.g  gender, ages_18_39, ages_40_59, ages_60+, 
    #         emergency, inpatient, outpatient_and_others, 'encounter', 
    #        'admitted_date_first', 'admitted_date_last', 'year_span'
    
    
# delete gender_male, only use gender female
demographics_vec= np.array(['gender_female', 'ages_18_39', 'ages_40_59',   ##'gender_male', ##
           'ages_60+', 'emergency', 'inpatient', 
           'outpatient_and_others', 'encounter', 
           'discharged_dt_tm_first', 'discharged_dt_tm_last', 'year_span'])

## only choose 3 encounter type. there are more. e.g. following types from 250sus.. maybe change later
#array(['Emergency', 'Outpatient', 'Not Mapped', 'Unknown / Invalid',
#        'Radiology', 'Inpatient', 'Laboratory', 'Other Specialty',
#        'Clinic', 'Outpatient Surgery', 'Observation',
#        'Observation / Short stay / 24 hr stay', 'Preadmit', 'Community',
#        'Recurring', 'Series', 'Non-Patient', 'Day Surgery',
#        'Physician Business', 'Urgent', 'Obstetrics'], dtype=object)
### combine into feature space
feature_vec = np.append(code_vec, demographics_vec)
k_code = code_vec.shape[0]  
k_demo = feature_vec.shape[0]  
K = feature_vec.shape[0] #k_code + k_demo 

        
patient_index = {patient_vec[i]:i for i in range(0, N)}
feature_index = {feature_vec[i]:i for i in range(0, K)}

# Step 3, Build a N*K feature matrix. and dump
#import ipdb; 
#start_time2 = time.time()
       
X = np.zeros((N,K))
Ybpd = np.zeros(N)
Ybpd_suicide_bipolar_flag = [None]*N
last_patient_sk = -1
last_encounter_id = -1
    
    
for index, row in df_cohort_.iterrows():
    patient_sk = row['patient_sk']
    encounter_id = row['encounter_id']
    diagnosis_code = row['diagnosis_code']
    age = row['age_first_diag']
    gender = row['gender']
    discharged_dt_tm = pd.Timestamp(row['discharged_dt_tm']).value # to_numpy()
    suicide_bipolar_flag = row['suicide_bipolar_flag'] #.lower()
    
    
    if isinstance(gender, str):
        gender = gender.lower()
    patient_type_desc = row['patient_type_desc']
    if isinstance(patient_type_desc, str): #can be nan
        patient_type_desc = patient_type_desc.lower()


    n = patient_index[patient_sk]

    if b_ccsr_encoding:
        if diagnosis_code in icd_ccsr:
            k = feature_index[icd_ccsr[diagnosis_code]]
            X[n, k] += 1 
    else:
        if diagnosis_code in feature_index:
            k = feature_index[diagnosis_code]
            X[n, k] += 1


    if diagnosis_code == 'F60.3':
        Ybpd[n] += 1

    if patient_sk != last_patient_sk:
        if gender == 'female':
            k_gender = feature_index['gender_female']
            X[n, k_gender]=1

        if age <= 39:
            k_age = feature_index['ages_18_39']
        elif age <= 59:
            k_age = feature_index['ages_40_59']
        else:
            k_age = feature_index['ages_60+']

        X[n, k_age]=1


        Ybpd_suicide_bipolar_flag[n] = suicide_bipolar_flag


# initialize
    if X[n, feature_index['discharged_dt_tm_first']] == 0:
        X[n, feature_index['discharged_dt_tm_first']] = discharged_dt_tm
    if X[n, feature_index['discharged_dt_tm_last']] == 0:
        X[n, feature_index['discharged_dt_tm_last']] = discharged_dt_tm

    if discharged_dt_tm < X[n, feature_index['discharged_dt_tm_first']]:
        X[n, feature_index['discharged_dt_tm_first']] = discharged_dt_tm
    if discharged_dt_tm > X[n, feature_index['discharged_dt_tm_last']]:
        X[n, feature_index['discharged_dt_tm_last']] = discharged_dt_tm


    if encounter_id != last_encounter_id:
        if patient_type_desc == 'emergency':
            k_enc = feature_index['emergency']
        elif patient_type_desc == 'inpatient':
            k_enc = feature_index['inpatient']
        else:
            k_enc = feature_index['outpatient_and_others']
    
        X[n, k_enc] += 1

        X[n, feature_index['encounter']] += 1 # total encounder

  
    last_patient_sk = patient_sk
    last_encounter_id = encounter_id

    
###Part III Apply pre-defined inclusion/ exclusion criteria.
 
pd_X = pd.DataFrame(data=X,    # values
            index=patient_vec,    # 1st column as index
            columns=feature_vec)
pd_X['discharged_dt_tm_first'] = pd.to_datetime(pd_X['discharged_dt_tm_first'])
pd_X['discharged_dt_tm_last'] = pd.to_datetime(pd_X['discharged_dt_tm_last'])
pd_X['year_span'] = ((pd_X['discharged_dt_tm_last'] - pd_X['discharged_dt_tm_first'] )).apply( lambda x:x.days/365) 

#Apply Inclusion/Exlcusion Criteria
raw_ie = pd.read_excel('iecode.xlsx',  sheet_name='Sheet1',skip_blank_lines=True)
 
        
        
e2 = raw_ie[raw_ie['Group']=='E2']

ielist = e2[~((e2['diagnosis']=='schizophrenia') & (e2['Description'].str.contains('Schizophreniform')))]
ielist.reset_index(drop=True, inplace=True)


schizophrenia = ielist[ielist['diagnosis']=='schizophrenia']
schizoaffective = ielist[ielist['diagnosis']=='schizoaffective disorder']
schizophreniform  = ielist[ielist['diagnosis']=='schizophreniform disorder']
delusional  = ielist[ielist['diagnosis']=='delusional disorder']

   
exclusion_vec = ielist['ICD code']
criteria_name_vec = ielist['diagnosis'].unique()

feature_vec_ie = np.append(exclusion_vec, criteria_name_vec)
K_ie = feature_vec_ie.shape[0] #k_code + k_demo  # 155+7 = 162 


patient_index = {patient_vec[i]:i for i in range(0, N)}
feature_index_ie = {feature_vec_ie[i]:i for i in range(0, K_ie)}


X_ie = np.zeros((N,K_ie))
    
#last_patient_sk = -1
#last_encounter_id = -1
for index, row in df_cohort_.iterrows():
    patient_sk = row['patient_sk']
    encounter_id = row['encounter_id']
    diagnosis_code = row['diagnosis_code']

    age = row['age_in_years']
    gender = row['gender']
    if isinstance(gender, str):
        gender = gender.lower()
    patient_type_desc = row['patient_type_desc']
    if isinstance(patient_type_desc, str): #can be nan
        patient_type_desc = patient_type_desc.lower()
    
    n = patient_index[patient_sk]
    if diagnosis_code in feature_index_ie:
        k = feature_index_ie[diagnosis_code]
        X_ie[n, k] += 1 
        
    if diagnosis_code in schizophrenia[r'ICD code'].tolist():
        k = feature_index_ie[r'schizophrenia']
        X_ie[n, k] += 1 
        
    if diagnosis_code in schizoaffective[r'ICD code'].tolist():
        k = feature_index_ie[r'schizoaffective disorder']
        X_ie[n, k] += 1
        
    if diagnosis_code in schizophreniform[r'ICD code'].tolist():
        k = feature_index_ie[r'schizophreniform disorder']
        X_ie[n, k] += 1
        
    if diagnosis_code in delusional[r'ICD code'].tolist():
        k = feature_index_ie[r'delusional disorder']
        X_ie[n, k] += 1
 


        
pd_X_ie = pd.DataFrame(data=X_ie,    # values
                    index=patient_vec,    # 1st column as index
                    columns=feature_index_ie)
pd_X_ie['schizophrenia.flag'] = pd_X_ie['schizophrenia']>0
pd_X_ie['schizoaffective.flag'] = pd_X_ie['schizoaffective disorder']>0
pd_X_ie['schizophreniform.flag'] = pd_X_ie['schizophreniform disorder']>0
pd_X_ie['delusional.flag'] = pd_X_ie['delusional disorder']>0


pd_X_ie1 = pd_X_ie[(pd_X_ie["schizophrenia.flag"]==0) & (pd_X_ie["schizoaffective.flag"]==0)& (pd_X_ie["schizophreniform.flag"]==0)
        & (pd_X_ie["delusional.flag"]==0)  ]

pd_X_ie2 = pd_X.merge(pd_X_ie1, left_index= True, right_index=True)
pd_X_ie2 = pd_X_ie2.iloc[:,0:211]

       
###Part V Feature Engineering
    
#feature egineering step to build up matrix function which specifies input features for the screening model

def feature_transform(x_in, choice='bool', year_normalized=False, drop_gender=False, drop_year=True):
    # a simple one
    x = x_in.copy()
    x.drop(columns=['discharged_dt_tm_first', 'discharged_dt_tm_last'], inplace=True)
    # set null value, year_span and date may have null value
    x['year_span'].fillna(1, inplace=True) #set year_span null to 1
    cnt_col = list(set(x.columns) - set(['gender_female',  'ages_18_39', 'ages_40_59',
       'ages_60+', 'year_span'])) # , 
    
    if drop_gender:
        drop_list = ['gender_female', 'PRG001_unrelated', 'PRG002_unrelated', 
                     'PRG023_unrelated', 'PRG028_unrelated', 'PRG029_unrelated', 'PRG030_unrelated',
                     'GEN017_unrelated', 'GEN018_unrelated', 'GEN021_unrelated','GEN025_unrelated'
                    ]
         
        x.drop(columns=drop_list, inplace=True)
        
    
    if year_normalized:
        x[cnt_col] = x[cnt_col].div(x['year_span'], axis=0) # normalized by year span
    
    cnt_col = cnt_col + ['year_span',] # add year_span for normalization
    
    if choice == 'log':
        x[cnt_col] = np.log(x[cnt_col]+1)
    elif choice == 'minmax':
        x[cnt_col] = (x[cnt_col] - x[cnt_col].min()) / (x[cnt_col].max() - x[cnt_col].min()+1e-8)
    elif choice == 'logminmax':
        x[cnt_col] = np.log(x[cnt_col]+1)
        x[cnt_col] = (x[cnt_col] - x[cnt_col].min()) / (x[cnt_col].max() - x[cnt_col].min()+1e-8)
    elif choice == 'bool':
        x['emergency_0'] = 0
        x['emergency_b'] = 0
        x['emergency_m'] = 0
        x['emergency_t'] = 0

        x['inpatient_0'] = 0
        x['inpatient_b'] = 0
        x['inpatient_m'] = 0
        x['inpatient_t'] = 0

        x['outpatient_and_others_0'] = 0
        x['outpatient_and_others_b'] = 0
        x['outpatient_and_others_m'] = 0
        x['outpatient_and_others_t'] = 0

        x['encounter_0'] = 0
        x['encounter_b'] = 0
        x['encounter_m'] = 0
        x['encounter_t'] = 0

        if not drop_year:
            print('keep year_span dims')
            x['year_span_1'] = 0
            x['year_span_2'] = 0
            x['year_span_3'] = 0
        else:
            print('drop year_span dims')
 

        for index, row in x.iterrows():
            emergency = row['emergency']
            inpatient = row['inpatient']
            outpatient_and_others = row['outpatient_and_others']
            encounter = row['encounter']
            year_span = row['year_span']

            if emergency == 0:
                x.loc[index, 'emergency_0']=1
            elif emergency<= 2:
                x.loc[index, 'emergency_b']=1
            elif emergency<= 5:
                x.loc[index, 'emergency_m']=1
            else:
                x.loc[index, 'emergency_t'] = 1
                

            if inpatient == 0:
                x.loc[index, 'inpatient_0']=1
            elif inpatient<= 1:
                x.loc[index, 'inpatient_b']=1
            elif inpatient<= 2:
                x.loc[index, 'inpatient_m']=1
            else:
                x.loc[index, 'inpatient_t'] = 1

            if outpatient_and_others == 0:
                x.loc[index, 'outpatient_and_others_0']=1
            elif outpatient_and_others<= 5:
                x.loc[index, 'outpatient_and_others_b']=1
            elif outpatient_and_others<= 14:
                x.loc[index, 'outpatient_and_others_m']=1
            else:
                x.loc[index, 'outpatient_and_others_t'] = 1

            if encounter == 0:
                x.loc[index, 'encounter_0']=1
            elif encounter<= 7:
                x.loc[index, 'encounter_b']=1
            elif encounter<= 15:
                x.loc[index, 'encounter_m']=1
            else:
                x.loc[index, 'encounter_t'] = 1 
            
            if not drop_year:
                if year_span <= 1:
                    x.loc[index, 'year_span_1']=1
                elif year_span <= 2:
                    x.loc[index, 'year_span_2']=1
                elif year_span <= 3:
                    x.loc[index, 'year_span_3']=1
                else:
                    print("outlier yeay_span at {} is {}".format(index, year_span))

        
        x.drop(columns=['emergency', 'inpatient', 'outpatient_and_others', 'encounter', 'year_span'], inplace=True)
        x = x > 0
        

    return x.astype(dtype='float') 

    
X_test = feature_transform(pd_X_ie2)
        
     
    ###Part IV Screening Model Implementation       
        
    
model_file = 'trained_model.pkl'
best_models_2 = pickle.load(open(model_file, 'rb'))
test_results_model2 = {}
adj_model = best_models_2['ADJ']

for name, model in best_models_2.items():


    if name == 'ADJ':

        continue

    if isinstance(model, (
            skorch.NeuralNetClassifier, 
            skorch.classifier.NeuralNetClassifier, 
            nn.Module)
                     ):
        y_predicted = model.predict(torch.from_numpy(X_test.values).float())
        y_predicted_proba = model.predict_proba(torch.from_numpy(X_test.values).float())
            
    else:
        y_predicted = model.predict(X_test)
        y_predicted_proba = model.predict_proba(X_test)
            
    
    adjusted_coef= adj_model.predict_proba(X_test)[:,1]
    threshold_adj = 0.5
    threshold_final = 0.5
    adjusted_coef[adjusted_coef>=threshold_adj] = 1


    y_predicted_prob_adjusted = adjusted_coef * y_predicted_proba[:,1]
    y_predicted_label_adjusted = (y_predicted_prob_adjusted >threshold_final).astype(int) 
    
        
    test_results_model2[name] = y_predicted
    test_results_model2[name +'_proba1'] = y_predicted_proba[:,1]
  
    test_results_model2[name +'_adjusted'] = y_predicted_label_adjusted
    test_results_model2[name +'_adjusted_prob1'] = y_predicted_prob_adjusted

       
pd_test_results_model2 =  pd.DataFrame(data=test_results_model2,index=X_test.index)
            
            

pd_test_results_model2['patient_sk'] = pd_test_results_model2.index
pd_test_results_model2 =  pd_test_results_model2.sort_values(by=['LR_adjusted_prob1'], ascending=False)
positive = pd_test_results_model2[pd_test_results_model2.LR_adjusted == 1]
positive = positive.T.reset_index().T
positive = positive.rename(columns={0:'a', 1:'b', 2:'c',3:'d', 4:'List of highly likely BoPD patients ordered by predicted likelihood'})
positive1 = positive.drop(['index'])
   
positive1['List of highly likely BoPD patients ordered by predicted likelihood'] = positive1['List of highly likely BoPD patients ordered by predicted likelihood'].astype(int)
#positive1 = positive1.reset_index(drop=True)
#positive = positive.reset_index(drop=True)
        
    
positive1['List of highly likely BoPD patients ordered by predicted likelihood'].to_string(index=False)
positive['List of highly likely BoPD patients ordered by predicted likelihood'].to_excel("highly likely BoPD patient list.xlsx")
    




